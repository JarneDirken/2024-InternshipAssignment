/*
  Warnings:

  - You are about to drop the column `generalItemId` on the `Item` table. All the data in the column will be lost.
  - You are about to drop the column `borrowManagerId` on the `ItemRequest` table. All the data in the column will be lost.
  - You are about to drop the column `messae` on the `ItemRequest` table. All the data in the column will be lost.
  - You are about to drop the column `returnManagerId` on the `ItemRequest` table. All the data in the column will be lost.
  - You are about to drop the column `generalItemId` on the `RoleItem` table. All the data in the column will be lost.
  - You are about to alter the column `studentCode` on the `User` table. The data in that column could be lost. The data in that column will be cast from `Text` to `Char(8)`.
  - You are about to drop the `GeneralItem` table. If the table is not empty, all the data it contains will be lost.
  - A unique constraint covering the columns `[name]` on the table `Item` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[number]` on the table `Item` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[schoolNumber]` on the table `Item` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `brand` to the `Item` table without a default value. This is not possible if the table is not empty.
  - Added the required column `model` to the `Item` table without a default value. This is not possible if the table is not empty.
  - Added the required column `name` to the `Item` table without a default value. This is not possible if the table is not empty.
  - Added the required column `number` to the `Item` table without a default value. This is not possible if the table is not empty.
  - Added the required column `itemId` to the `RoleItem` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "Item" DROP CONSTRAINT "Item_generalItemId_fkey";

-- DropForeignKey
ALTER TABLE "ItemRequest" DROP CONSTRAINT "ItemRequest_borrowManagerId_fkey";

-- DropForeignKey
ALTER TABLE "ItemRequest" DROP CONSTRAINT "ItemRequest_returnManagerId_fkey";

-- DropForeignKey
ALTER TABLE "RoleItem" DROP CONSTRAINT "RoleItem_generalItemId_fkey";

-- AlterTable
ALTER TABLE "Item" DROP COLUMN "generalItemId",
ADD COLUMN     "brand" TEXT NOT NULL,
ADD COLUMN     "image" BYTEA,
ADD COLUMN     "model" TEXT NOT NULL,
ADD COLUMN     "name" TEXT NOT NULL,
ADD COLUMN     "notes" TEXT,
ADD COLUMN     "number" TEXT NOT NULL,
ADD COLUMN     "schoolNumber" TEXT;

-- AlterTable
ALTER TABLE "ItemRequest" DROP COLUMN "borrowManagerId",
DROP COLUMN "messae",
DROP COLUMN "returnManagerId",
ADD COLUMN     "approveMessage" TEXT,
ADD COLUMN     "file" BYTEA,
ADD COLUMN     "receiveMessage" TEXT;

-- AlterTable
ALTER TABLE "RoleItem" DROP COLUMN "generalItemId",
ADD COLUMN     "itemId" INTEGER NOT NULL;

-- AlterTable
ALTER TABLE "User" ALTER COLUMN "studentCode" SET DATA TYPE CHAR(8);

-- DropTable
DROP TABLE "GeneralItem";

-- CreateIndex
CREATE UNIQUE INDEX "Item_name_key" ON "Item"("name");

-- CreateIndex
CREATE UNIQUE INDEX "Item_number_key" ON "Item"("number");

-- CreateIndex
CREATE UNIQUE INDEX "Item_schoolNumber_key" ON "Item"("schoolNumber");

-- AddForeignKey
ALTER TABLE "RoleItem" ADD CONSTRAINT "RoleItem_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES "Item"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
