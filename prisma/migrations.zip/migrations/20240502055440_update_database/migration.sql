/*
  Warnings:

  - You are about to drop the column `starBorrowDate` on the `ItemRequest` table. All the data in the column will be lost.
  - Added the required column `startBorrowDate` to the `ItemRequest` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "ItemRequest" DROP CONSTRAINT "ItemRequest_approverId_fkey";

-- DropForeignKey
ALTER TABLE "ItemRequest" DROP CONSTRAINT "ItemRequest_borrowerId_fkey";

-- AlterTable
ALTER TABLE "ItemRequest" DROP COLUMN "starBorrowDate",
ADD COLUMN     "startBorrowDate" TIMESTAMP(3) NOT NULL,
ALTER COLUMN "borrowerId" SET DATA TYPE TEXT,
ALTER COLUMN "approverId" DROP NOT NULL,
ALTER COLUMN "approverId" SET DATA TYPE TEXT;

-- AlterTable
ALTER TABLE "Reparation" ALTER COLUMN "returnDate" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "ItemRequest" ADD CONSTRAINT "ItemRequest_borrowerId_fkey" FOREIGN KEY ("borrowerId") REFERENCES "User"("firebaseUid") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ItemRequest" ADD CONSTRAINT "ItemRequest_approverId_fkey" FOREIGN KEY ("approverId") REFERENCES "User"("firebaseUid") ON DELETE SET NULL ON UPDATE CASCADE;
