-- AlterTable
ALTER TABLE "User" ALTER COLUMN "studentCode" DROP NOT NULL;
